package estructurasdlineales.auxiliares;

import estructurasdlineales.Nodo;

public class NodoBusqueda {
    public Nodo buscado;
    public Nodo anterior;
    
    public Nodo getBuscado() {
        return buscado;
    }
    public void setBuscado(Nodo buscado) {
        this.buscado = buscado;
    }
    public Nodo getAnterior() {
        return anterior;
    }
    public void setAnterior(Nodo anterior) {
        this.anterior = anterior;
    }

    
}
