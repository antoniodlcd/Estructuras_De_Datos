package pruebas;

import estructurasdnolineales.ArchivoManejoErrores;

public class PruebaArchivoErrores {
    public static void main(String[] args) {
        
        String rutaArchivo = "src\\estructurasdnolineales\\ArchivoManejoErrores.java";
        ArchivoManejoErrores archivo1 = new ArchivoManejoErrores(rutaArchivo);
        
        archivo1.imprimir();
    }

}
