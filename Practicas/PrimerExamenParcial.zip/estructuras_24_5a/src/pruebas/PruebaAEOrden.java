// package pruebas;

// import entradasalida.FlujoSalida;
// import estructurasdlineales.ArregloListaInfoEstaticaOrden;

// public class PruebaAEOrden {
//     public static void main(String[] args) {
//         ArregloListaInfoEstaticaOrden arreglo1 = new ArregloListaInfoEstaticaOrden(6);

//         arreglo1.nuevo(5);
//         arreglo1.nuevo(6);
//         arreglo1.nuevo(2);
//         arreglo1.nuevo(9);
//         arreglo1.nuevo(4);
//         arreglo1.nuevo(7);

//         arreglo1.imprimir();

//         int posicion = arreglo1.buscar(2);
//         FlujoSalida.mostrarConsola("Buscando el 6: " + posicion + "\n");

//         posicion = arreglo1.buscar(20);
//         FlujoSalida.mostrarConsola("Buscando el 20: " + posicion + "\n");

//         Object objeto = arreglo1.eliminar(6);
//         FlujoSalida.mostrarConsola("Quitando el 6 del arreglo 1: " + objeto + "\n");
        
//         arreglo1.imprimir();

//     }
// }
