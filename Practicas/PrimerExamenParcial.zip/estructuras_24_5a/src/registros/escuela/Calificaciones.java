package registros.escuela;

public class Calificaciones {
        // protected 
}
