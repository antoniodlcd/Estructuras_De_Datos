package registros;

public class IndicesCubo {
    protected int indiceX;
    protected int indiceY;
    protected int indiceZ;

    public int getIndiceX() {
        return indiceX;
    }
    public void setIndiceX(int indiceX) {
        this.indiceX = indiceX;
    }
    public int getIndiceY() {
        return indiceY;
    }
    public void setIndiceY(int indiceY) {
        this.indiceY = indiceY;
    }
    public int getIndiceZ() {
        return indiceZ;
    }
    public void setIndiceZ(int indiceZ) {
        this.indiceZ = indiceZ;
    }

    
}
