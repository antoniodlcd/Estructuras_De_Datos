package estructurasdlineales;

import entradasalida.FlujoSalida;
import java.lang.Math;

public class ArregloListaInfoEstaticaNumeros extends ArregloListaInfoEstatica {
    public ArregloListaInfoEstaticaNumeros(int max) {
        super(max);
    }

    // metodos sobre-escritos para las operaciones necesarias
    @Override
    public Integer buscar(Object valor) {
        if (valor instanceof Number) {
            return super.buscar(valor);
        } else {
            return null;
        }
    }

    @Override   
    public boolean modificar(Object valorViejo, Object valorNuevo) {
        if ((valorViejo instanceof Number) && (valorNuevo instanceof Number)) {
            return super.modificar(valorViejo, valorNuevo);
        } else {
            return false;
        }
    }

    @Override
    public Integer nuevo(Object valor) {
        if (valor instanceof Number) {
            return super.nuevo(valor);
        } else {
            return null;
        }
    }

    @Override
    public Object quitar(Object valor) {
        if (valor instanceof Number) {
            return super.quitar(valor);
        } else {
            return null;
        }
    }

    @Override
    public boolean porEscalar(Number escalar) {
        if (vacio()) {
            return false;
        } else {
            for (int posicion = 0; posicion <= indiceUltimo; posicion++) {
                Object valorPosicion = arreglo[posicion];
                if (valorPosicion instanceof Number) {
                    Number valor = (Number)valorPosicion;
                    Double producto = escalar.doubleValue() * valor.doubleValue();
                    FlujoSalida.mostrarConsola(producto.toString() + "\t");
                } else {
                    return false;
                }
            }
            return super.porEscalar(escalar);
            
        }
    }

    @Override
    public boolean sumarEscalar(Number escalar) {
        if (vacio()) {
            return false;
        } else {
            for (int posicion = 0; posicion <= indiceUltimo; posicion++) {
                Object valorPosicion = arreglo[posicion];
                if (valorPosicion instanceof Number) {
                    Number valor = (Number)valorPosicion;
                    Double suma = escalar.doubleValue() + valor.doubleValue();
                    FlujoSalida.mostrarConsola(suma.toString() + "\t");
                } else {
                    return false;
                }
            }
            return super.sumarEscalar(escalar);
        }
    }

    @Override
    public boolean sumar(ArregloListaInfoEstaticaNumeros arreglo2) {
        if (indiceUltimo != arreglo2.indiceUltimo) {
            return false;
        }

        for (int posicion = 0; posicion <= indiceUltimo; posicion++) {
            Object valorArreglo1 = arreglo[posicion];
            Object valorArreglo2 = arreglo2.arreglo[posicion];

            if ((valorArreglo1 instanceof Number) && (valorArreglo2 instanceof Number)) {
                Number valor1 = (Number)valorArreglo1;
                Number valor2 = (Number)valorArreglo2;

                Double suma = valor1.doubleValue() + valor2.doubleValue();
                FlujoSalida.mostrarConsola(suma.toString() + "\t");
            } else {
                
            }
        }

        return super.sumar(arreglo2);

    }
    
    @Override
    public boolean multiplicar(ArregloListaInfoEstaticaNumeros arreglo2) {
        if (indiceUltimo != arreglo2.indiceUltimo) {
            return false;
        }

        for (int posicion = 0; posicion <= indiceUltimo; posicion++) {
            Object valorArreglo1 = arreglo[posicion];
            Object valorArreglo2 = arreglo2.arreglo[posicion];

            if ((valorArreglo1 instanceof Number) && (valorArreglo2 instanceof Number)) {
                Number valor1 = (Number)valorArreglo1;
                Number valor2 = (Number)valorArreglo2;

                Double suma = valor1.doubleValue() * valor2.doubleValue();
                FlujoSalida.mostrarConsola(suma.toString() + "\t");
            } else {
                
            }
        }

        return super.multiplicar(arreglo2);
    }

    @Override
    public boolean aplicarPotencia(Number escalar) {
        if (vacio()) {
            return false;
        } else {
            for (int posicion = 0; posicion <= indiceUltimo; posicion++) {
                Object valorPosicion = arreglo[posicion];
                if (valorPosicion instanceof Number) {
                    Number valor = (Number)valorPosicion;
                    Double potencia = escalar.doubleValue()  valor.doubleValue();
                    FlujoSalida.mostrarConsola(potencia.toString() + "\t");
                } else {
                    return false;
                }
            }
            return super.sumarEscalar(escalar);
        }
    }

   
    

    
}
