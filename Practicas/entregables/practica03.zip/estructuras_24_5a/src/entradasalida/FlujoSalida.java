package entradasalida;

public class FlujoSalida {
    public static void mostrarConsola(String dato) {
        System.out.print(dato);
    }
}
